"""
DnD Dice Roller GUI

Elijah Walls

created 2/26/24

Program allows user to roll up to 5 of the same dice. The dice options include
D4, D6, D8, D10, D12, and a D20 (the number represnets the number of sides on the dice).

The program provides statistics about the user's rolls, as well a small amount of 
information on what the purpose of each die. The statistics also include fun facts
about the user's rolls such as their "unluckiest dice" (lowest average roll).

Ver 0.1 updated 2/29/24

"""

from tkinter import *
import random
import ast

# Global variables to store the image labels
SuccessImageLabel = None
FailImageLabel = None

# Function to roll dice
def RollDice(sides, quantity):
    Results = [random.randint(1, sides) for _ in range(quantity)]
    for result in Results:
        DiceRollCounts[sides]["Total Rolls"] += 1
        DiceRollCounts[sides][result] += 1
        DiceRollCounts[sides]["Last Roll"] = result
    UpdateStatisticsFile()
    return Results

# Function to update quantity of dice
def UpdateQuantity(change):
    CurrentQuality = int(QualityLabel.cget("text"))
    NewQuantity = max(1, min(5, CurrentQuality + change))  # Ensure quantity is between 1 and 5
    QualityLabel.config(text=str(NewQuantity))

# Function to clear statistics for a specific dice
def ClearDiceStatistics(sides):
    DiceRollCounts[sides] = {"Total Rolls": 0, "Last Roll": None}
    for i in range(1, sides + 1):
        DiceRollCounts[sides][i] = 0
    UpdateStatisticsFile()

# Function to calculate average roll
def CalculateAverageRoll(sides):
    TotalRolls = DiceRollCounts[sides]["Total Rolls"]
    TotalSum = sum([key * value for key, value in DiceRollCounts[sides].items() if type(key) == int])
    if TotalRolls > 0:
        return TotalSum / TotalRolls
    else:
        return 0

# Function to show statistics for a specific dice
def ShowDiceStatistics(sides, ParentWindow):
    StatsWindow = Toplevel(ParentWindow)
    StatsWindow.title(f"D{sides} Statistics")
    StatsWindow.geometry("500x700")  # Increase height of the window

    # Display statistics for the selected dice
    StatsLabel = Label(StatsWindow, text=f"D{sides} Statistics", font=("Helvetica", 16, "bold"))
    StatsLabel.pack(pady=10)

    # Display individual sides' statistics
    for i in range(1, sides + 1):
        StatsEntry = Label(StatsWindow, text=f"Side {i}: {DiceRollCounts[sides][i]} times")
        StatsEntry.pack()

    # Additional statistics such as last roll, total rolls for a dice, so on.
    LastRollLabel = Label(StatsWindow, text=f"Last Roll: {DiceRollCounts[sides]['Last Roll']}")
    LastRollLabel.pack()

    TotalRollsLabel = Label(StatsWindow, text=f"Total Rolls: {DiceRollCounts[sides]['Total Rolls']}")
    TotalRollsLabel.pack()

    MostCommonRollLabel = Label(StatsWindow, text=f"Most Common Roll: {max(range(1, sides + 1), key=lambda x: DiceRollCounts[sides][x])}")
    MostCommonRollLabel.pack()

    LeastCommonRollLabel = Label(StatsWindow, text=f"Least Common Roll: {min(range(1, sides + 1), key=lambda x: DiceRollCounts[sides][x])}")
    LeastCommonRollLabel.pack()

    AverageRollLabel = Label(StatsWindow, text=f"Average Roll: {CalculateAverageRoll(sides):.2f}")
    AverageRollLabel.pack()

    # Button to clear statistics for this dice
    ClearButton = Button(StatsWindow, text="Clear Statistics", command=lambda s=sides: (ClearDiceStatistics(s), StatsWindow.destroy()))
    ClearButton.pack(pady=10)

    # Button to exit the statistics window
    ExitButton = Button(StatsWindow, text="Exit", command=lambda: ExitProgram(StatsWindow))
    ExitButton.pack(pady=10)

    StatsWindow.mainloop()

# Function to show statistics
def ShowStatistics():
    StatsWindow = Tk()
    StatsWindow.title("All Dice Statistics")
    StatsWindow.geometry("800x400")  

    # Display statistics for the selected dice
    StatsLabel = Label(StatsWindow, text="Dice Statistics", font=("Helvetica", 16, "bold"))
    StatsLabel.pack(pady=10)

    # Display fun facts
    FunFactsFrame = Frame(StatsWindow)
    FunFactsFrame.pack(side=TOP, pady=10)
    
    LuckiestDiceLabel = Label(FunFactsFrame, text=f"Luckiest Dice: D{max(DiceRollCounts, key=lambda x: CalculateAverageRoll(x))}")
    LuckiestDiceLabel.pack(side=LEFT, padx=10)

    UnluckiestDiceLabel = Label(FunFactsFrame, text=f"Unluckiest Dice: D{min(DiceRollCounts, key=lambda x: CalculateAverageRoll(x))}")
    UnluckiestDiceLabel.pack(side=LEFT, padx=10)

    FavoriteDiceLabel = Label(FunFactsFrame, text=f"Favorite Dice: D{max(DiceRollCounts, key=lambda x: DiceRollCounts[x]['Total Rolls'])}")
    FavoriteDiceLabel.pack(side=LEFT, padx=10)

    LeastFavoriteDiceLabel = Label(FunFactsFrame, text=f"Least Favorite Dice: D{min(DiceRollCounts, key=lambda x: DiceRollCounts[x]['Total Rolls'])}")
    LeastFavoriteDiceLabel.pack(side=LEFT, padx=10)

    # Display buttons for each dice to show their statistics
    for sides in DiceRollCounts.keys():
        Button(StatsWindow, text=f"D{sides}", command=lambda s=sides: ShowDiceStatistics(s, StatsWindow)).pack(pady=5)

    # Button to exit the statistics window
    ExitButton = Button(StatsWindow, text="Exit", command=lambda: ExitProgram(StatsWindow))
    ExitButton.pack(pady=10)

    StatsWindow.mainloop()

# Function to roll the selected dice with the selected quantity
def RollSelectedDice(sides):
    Quantity = int(QualityLabel.cget("text"))
    Results = RollDice(sides, Quantity)
    ResultLabel.config(text=f"{Quantity}x {sides} sided dice: {Results}", font=("Helvetica", 24))

    # Display images for critical success or failure
    global SuccessImageLabel
    global FailImageLabel

    # Delete existing images
    if SuccessImageLabel:
        SuccessImageLabel.destroy()
        SuccessImageLabel = None
    if FailImageLabel:
        FailImageLabel.destroy()
        FailImageLabel = None

    # Check for critical success or failure
    if sides == 20:
        if 20 in Results and 1 not in Results:
            DisplayImage("CriticalSuccess.png")
        elif 1 in Results and 20 not in Results:
            DisplayImage("CriticalFail.png")
        elif 20 in Results and 1 in Results:
            DisplayImage("CriticalSuccess.png")

# Function to update the statistics file
def UpdateStatisticsFile():
    with open("statistics.txt", "w") as file:
        file.write(str(DiceRollCounts))

# Function to display an image
def DisplayImage(ImageFilename):
    global SuccessImageLabel
    global FailImageLabel

    image = PhotoImage(file=ImageFilename)
    if "Success" in ImageFilename:
        SuccessImageLabel = Label(root, image=image)
        SuccessImageLabel.image = image
        SuccessImageLabel.pack()
    elif "Fail" in ImageFilename:
        FailImageLabel = Label(root, image=image)
        FailImageLabel.image = image
        FailImageLabel.pack()

# Function to exit the program
def ExitProgram(window):
    window.destroy()

# Read statistics from file when the program starts
try:
    with open("statistics.txt", "r") as file:
        DiceRollCounts = ast.literal_eval(file.read())
except FileNotFoundError:
    print("Statistics file not found. Initializing with default values.")
    # Initialize DiceRollCounts with default values
    DiceRollCounts = {4: {"Total Rolls": 0, "Last Roll": None, **{i: 0 for i in range(1, 5)}},
                      6: {"Total Rolls": 0, "Last Roll": None, **{i: 0 for i in range(1, 7)}},
                      8: {"Total Rolls": 0, "Last Roll": None, **{i: 0 for i in range(1, 9)}},
                      10: {"Total Rolls": 0, "Last Roll": None, **{i: 0 for i in range(1, 11)}},
                      12: {"Total Rolls": 0, "Last Roll": None, **{i: 0 for i in range(1, 13)}},
                      20: {"Total Rolls": 0, "Last Roll": None, **{i: 0 for i in range(1, 21)}}}

# Open a window
root = Tk()
root.title("D&D Dice Roller")
root.geometry("800x600")

# Title at the top of the GUI
TitleLabel = Label(root, text="D&D Dice Roller", font=("Helvetica", 20, "bold"))
TitleLabel.pack(pady=20)

# Button for exit
ExitButton = Button(root, text="Exit", command=root.quit)
ExitButton.place(relx=0.05, rely=0.05, anchor="nw")

# Button for statistics
StatisticsButton = Button(root, text="Statistics", command=ShowStatistics)
StatisticsButton.place(relx=0.9, rely=0.05, anchor="ne")

# Frame for buttons
ButtonFrame = Frame(root)
ButtonFrame.pack(side=BOTTOM, pady=10)

# Buttons for each type of dice
Button(ButtonFrame, text="D4", command=lambda: RollSelectedDice(4), width=3, height=2).pack(side=LEFT, padx=10)
Button(ButtonFrame, text="D6", command=lambda: RollSelectedDice(6), width=3, height=2).pack(side=LEFT, padx=10)
Button(ButtonFrame, text="D8", command=lambda: RollSelectedDice(8), width=3, height=2).pack(side=LEFT, padx=10)
Button(ButtonFrame, text="D10", command=lambda: RollSelectedDice(10), width=3, height=2).pack(side=LEFT, padx=10)
Button(ButtonFrame, text="D12", command=lambda: RollSelectedDice(12), width=3, height=2).pack(side=LEFT, padx=10)
Button(ButtonFrame, text="D20", command=lambda: RollSelectedDice(20), width=3, height=2).pack(side=LEFT, padx=10)

# Header for type of dice
NumOfDiceHeader = Label(root, text="Type of Dice", font=("Helvetica", 14, "bold"))
NumOfDiceHeader.pack(side=BOTTOM, pady=10)

# Frame for quantity controls
QuantityFrame = Frame(root)
QuantityFrame.pack(side=BOTTOM, pady=10)

# Buttons for adjusting quantity
Button(QuantityFrame, text="-", command=lambda: UpdateQuantity(-1), width=2, height=1).pack(side=LEFT, padx=10)
QualityLabel = Label(QuantityFrame, text="1")
QualityLabel.pack(side=LEFT)
Button(QuantityFrame, text="+", command=lambda: UpdateQuantity(1), width=2, height=1).pack(side=LEFT, padx=10)

# Header for number of dice
NumOfDiceHeader = Label(root, text="Number of Dice", font=("Helvetica", 14, "bold"))
NumOfDiceHeader.pack(side=BOTTOM, pady=10)

# Label to display roll results 
ResultLabel = Label(root, text="", font=("Helvetica", 24))
ResultLabel.pack(expand=True)

# Runs the program
root.mainloop()